﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


namespace ProductSConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("<**************************************************************************************>");
            Console.WriteLine("..................S H O P P I N G - A P P L I C A T I O N.................................\n");
            Console.WriteLine("<****************************************************************************************>\n");

            
            // connect sql server
            String connectionString = @"Data Source = XC-AZ-CTX051\SQLEXPRESS; Initial Catalog = creed; Integrated Security = True";
            SqlConnection sqlConnection =new SqlConnection(connectionString);
            sqlConnection.Open();
            
            //Exception handling
            try
            {       
                Console.Write("Your Connection Is Successfully Established \n");
                String jitin;
                do
                {

                    Console.WriteLine("Select From The Options Below\n1:-Create Your Order\n2:-Retrive(Show)Your Data\n3:-Update Your Details\n4:-Delete Your Order\n5:-Exit(X)");
                    Console.WriteLine("*****************************************************************************");
                    Console.WriteLine("Enter Your Choice[1-5]");
                    int Choice = int.Parse(Console.ReadLine());
                    switch (Choice)
                    {
                        case 1:
                            // Create => CRUD
                            Console.WriteLine("Enter Your Name");
                            String Customer_Name = Console.ReadLine();
                            Console.WriteLine("Name Submitted Successfully\n");
                            Console.WriteLine("Enter Your Phone_Number");
                            String Phone_Number = Console.ReadLine();
                            Console.WriteLine("Phone Number Submitted Successfully\n");
                            Console.WriteLine("Enter Your Product_Name");
                            String Product_Name = Console.ReadLine();
                            Console.WriteLine("Product Name Submitted Successfully\n");
                            Console.WriteLine("Enter Your Product_Qty");
                            int Product_Qty = int.Parse(Console.ReadLine());
                            Console.WriteLine("Product Qty Submitted Successfully\n");
                            Console.WriteLine("Enter Your Price");
                            int Price = int.Parse(Console.ReadLine());
                            Console.WriteLine("Price Submitted Successfully\n");
                            Console.WriteLine("Enter Your Delivery_Add_Type");
                            String Delivery_Add_Type = Console.ReadLine();
                            Console.WriteLine("Delivery Add Type Submitted Successfully\n");
                            Console.WriteLine("Enter Your Delivery_Address");
                            String Delivery_Address = Console.ReadLine();
                            Console.WriteLine("Delivery Address Submitted Successfully\n");
                            Console.WriteLine("Enter Your Pin_Code");
                            int Pin_Code = int.Parse(Console.ReadLine());
                            Console.WriteLine("Pin Code Submitted Successfully\n");
                            Console.WriteLine("Enter Your Payment_Type");
                            String Payment_Type = Console.ReadLine();
                            Console.WriteLine("OK\n");
                            Console.WriteLine("Enter Your Payment_Status");
                            String Payment_Status = Console.ReadLine();
                            Console.WriteLine("Payment Status Submitted Successfully");

                            String insertQuery = "INSERT INTO Product_T2(Customer_Name,Phone_Number,Product_Name,Product_Qty,Price,Delivery_Add_Type,Delivery_Address,Pin_Code,Payment_Type,Payment_Status) VALUES('" + Customer_Name + "','" + Phone_Number + "','" + Product_Name + "'," + Product_Qty + ", " + Price + ",'" + Delivery_Add_Type + "','" + Delivery_Address + "'," + Pin_Code + ",'" + Payment_Type + "','" + Payment_Status + "')";
                            SqlCommand insertCommand = new SqlCommand(insertQuery, sqlConnection);
                            //sqlConnection.Open();
                            int a = insertCommand.ExecuteNonQuery();
                            if (a > 0)
                            {
                                Console.WriteLine("Data is successfully Submitted into the table");
                            }
                            else
                            {
                                Console.WriteLine("Data insertion Failed");
                            }
                           // sqlConnection.Close();
                            break;

                        case 2:
                            // View 
                            String sqlQuery = "Select * from Product_T2";
                            //
                           // sqlConnection.Open();
                            SqlCommand command = new SqlCommand(sqlQuery, sqlConnection);
                            SqlDataReader reader = command.ExecuteReader();
                            while (reader.Read())
                            {
                                Console.WriteLine("---------------------------------------\n");
                                Console.WriteLine("[Customer Id] => " + reader.GetValue(0));
                                Console.WriteLine("---------------------------------------");
                                Console.WriteLine("Customer Name->  " + reader.GetValue(1));
                                Console.WriteLine("Phone Number->  " + reader.GetValue(2));
                                Console.WriteLine("Product_Name -> " + reader.GetValue(3));
                                Console.WriteLine("Product_Qty->  " + reader.GetValue(4));
                                Console.WriteLine("Price->   " + reader.GetValue(5));
                                Console.WriteLine("Delivery_Add_Type->  " + reader.GetValue(6));
                                Console.WriteLine("Delivery_Address->  " + reader.GetValue(7));
                                Console.WriteLine("Pin_Code -> " + reader.GetValue(8));
                                Console.WriteLine("Payment_Type->  " + reader.GetValue(9));
                                Console.WriteLine("Payment_Status->  " + reader.GetValue(10));

                            }
                            sqlConnection.Close();
                            break;
                        //UPDATE 
                        case 3:
                           
                            

                            Console.WriteLine("Which Field You Want To Update?");
                            Console.WriteLine("1: Customer Name");
                            Console.WriteLine("2: Phone Number");
                            Console.WriteLine("3: Product Name");
                            Console.WriteLine("4: Product Qty");
                            Console.WriteLine("5: Price");
                            Console.WriteLine("6: Delivery Add Type");
                            Console.WriteLine("7: Delivery Address");
                            Console.WriteLine("8: Pin_Code");
                            Console.WriteLine("9: Payment_Type");
                            Console.WriteLine("10: Payment_Status");
                            int Choice1 = int.Parse(Console.ReadLine());
                            switch (Choice1)
                            {
                                case 1:


                                    Console.WriteLine("Enter Customer Id:");
                                    int Customer_Id = int.Parse(Console.ReadLine());
                                    Console.WriteLine("Enter Customer Name");
                                    Customer_Name =Console.ReadLine();
                                    
                                    String updateQuery = ("UPDATE Product_T2 SET Customer_Name='" + Customer_Name +"' WHERE Customer_Id =" +Customer_Id );
                                    SqlCommand updateCommand = new SqlCommand(updateQuery, sqlConnection);
                                    
                                     
                                    int b = updateCommand.ExecuteNonQuery();
                                    
                                    if (b>0)
                                    {
                                        Console.WriteLine("Name Updated Successfully");

                                    }
                                    else
                                    {
                                        Console.WriteLine("Data updation Failed");
                                    }
                                    
                                    break;
                                    // Update
                                case 2:

                                    Console.WriteLine("Enter Customer Id:");
                                    Customer_Id = int.Parse(Console.ReadLine());
                                    Console.WriteLine("Enter Phone Number");
                                    Phone_Number = Console.ReadLine();

                                    String updateQuery1 = ("UPDATE Product_T2 SET Phone_Number='" + Phone_Number + "' WHERE Customer_Id =" + Customer_Id);
                                    SqlCommand updateCommand2 = new SqlCommand(updateQuery1, sqlConnection);
                                   
                                    int c = updateCommand2.ExecuteNonQuery();

                                    if (c > 0)
                                    {
                                        Console.WriteLine("Phone Number Updated Successfully");

                                    }
                                    else
                                    {
                                        Console.WriteLine("Data updation Failed");
                                    }

                                    break;
                                case 3:

                                    Console.WriteLine("Enter Customer Id:");
                                    Customer_Id = int.Parse(Console.ReadLine());
                                    Console.WriteLine("Enter Product Name");
                                    Product_Name = Console.ReadLine();

                                    String updateQuery2 = ("UPDATE Product_T2 SET Product_Name='" + Product_Name + "' WHERE Customer_Id =" + Customer_Id);
                                    SqlCommand updateCommand1 = new SqlCommand(updateQuery2, sqlConnection);

                                    int d = updateCommand1.ExecuteNonQuery();

                                    if (d > 0)
                                    {
                                        Console.WriteLine("Product Name Updated Successfully");

                                    }
                                    else
                                    {
                                        Console.WriteLine("Data updation Failed");
                                    }

                                    break;
                                case 4:

                                    Console.WriteLine("Enter Customer Id:");
                                    Customer_Id = int.Parse(Console.ReadLine());
                                    Console.WriteLine("Enter Product_Qty");
                                    Product_Qty = int.Parse(Console.ReadLine());

                                    String updateQuery3 = ("UPDATE Product_T2 SET Product_Qty='" + Product_Qty + "' WHERE Customer_Id =" + Customer_Id);
                                    SqlCommand updateCommand4 = new SqlCommand(updateQuery3, sqlConnection);

                                    int e = updateCommand4.ExecuteNonQuery();

                                    if (e > 0)
                                    {
                                        Console.WriteLine("Product Qty Updated Successfully");

                                    }
                                    else
                                    {
                                        Console.WriteLine("Data updation Failed");
                                    }

                                    break;
                                case 5:

                                    Console.WriteLine("Enter Customer Id:");
                                    Customer_Id = int.Parse(Console.ReadLine());
                                    Console.WriteLine("Price");
                                    Price = int.Parse(Console.ReadLine());

                                    String updateQuery4 = ("UPDATE Product_T2 SET Price='" + Price + "' WHERE Customer_Id =" + Customer_Id);
                                    SqlCommand updateCommand5 = new SqlCommand(updateQuery4, sqlConnection);

                                    int f = updateCommand5.ExecuteNonQuery();

                                    if (f > 0)
                                    {
                                        Console.WriteLine("Price Updated Successfully");

                                    }
                                    else
                                    {
                                        Console.WriteLine("Data updation Failed");
                                    }

                                    break;
                                case 6:

                                    Console.WriteLine("Enter Customer Id:");
                                    Customer_Id = int.Parse(Console.ReadLine());
                                    Console.WriteLine("Enter Delivery Add Type");
                                    Delivery_Add_Type = Console.ReadLine();

                                    String updateQuery5 = ("UPDATE Product_T2 SET Delivery_Add_Type='" + Delivery_Add_Type + "' WHERE Customer_Id =" + Customer_Id);
                                    SqlCommand updateCommand6 = new SqlCommand(updateQuery5, sqlConnection);

                                    int g = updateCommand6.ExecuteNonQuery();

                                    if (g > 0)
                                    {
                                        Console.WriteLine("Delivery_Add_Type Updated Successfully");

                                    }
                                    else
                                    {
                                        Console.WriteLine("Data updation Failed");
                                    }

                                    break;
                               
                                case 7:

                                    Console.WriteLine("Enter Customer Id:");
                                    Customer_Id = int.Parse(Console.ReadLine());
                                    Console.WriteLine("Enter Delivery_Address");
                                    Delivery_Address = Console.ReadLine();

                                    String updateQuery7 = ("UPDATE Product_T2 SET Delivery_Address='" + Delivery_Address + "' WHERE Customer_Id =" + Customer_Id);
                                    SqlCommand updateCommand8 = new SqlCommand(updateQuery7, sqlConnection);

                                    int i = updateCommand8.ExecuteNonQuery();

                                    if (i > 0)
                                    {
                                        Console.WriteLine("Delivery Address Updated Successfully");

                                    }
                                    else
                                    {
                                        Console.WriteLine("Data updation Failed");
                                    }

                                    break;
                                case 8:

                                    Console.WriteLine("Enter Customer Id:");
                                    Customer_Id = int.Parse(Console.ReadLine());
                                    Console.WriteLine("Enter [Pin_Code]");
                                    Pin_Code = int.Parse(Console.ReadLine());

                                    String updateQuery6 = ("UPDATE Product_T2 SET Pin_Code='" + Pin_Code + "' WHERE Customer_Id =" + Customer_Id);
                                    SqlCommand updateCommand7 = new SqlCommand(updateQuery6, sqlConnection);

                                    int h = updateCommand7.ExecuteNonQuery();

                                    if (h > 0)
                                    {

                                        Console.WriteLine("Pin Code Updated Successfully");

                                    }
                                    else
                                    {
                                        Console.WriteLine("Data updation Failed");
                                    }

                                    break;
                                case 9:

                                    Console.WriteLine("Enter Customer Id:");
                                    Customer_Id = int.Parse(Console.ReadLine());
                                    Console.WriteLine("Payment_Type");
                                    Payment_Type = Console.ReadLine();

                                    String updateQuery8 = ("UPDATE Product_T2 SET Payment_Type='" + Payment_Type + "' WHERE Customer_Id =" + Customer_Id);
                                    SqlCommand updateCommand9 = new SqlCommand(updateQuery8, sqlConnection);

                                    int x = updateCommand9.ExecuteNonQuery();

                                    if (x > 0)
                                    {
                                        Console.WriteLine("Payment Type Updated Successfully");

                                    }
                                    else
                                    {
                                        Console.WriteLine("Data updation Failed");
                                    }

                                    break;
                                case 10:

                                    Console.WriteLine("Enter Customer Id:");
                                    Customer_Id = int.Parse(Console.ReadLine());
                                    Console.WriteLine("Enter Payment_Status");
                                    Payment_Status = Console.ReadLine();

                                    String updateQuery9 = ("UPDATE Product_T2 SET Payment_Status='" + Payment_Status + "' WHERE Customer_Id =" + Customer_Id);
                                    SqlCommand updateCommand10 = new SqlCommand(updateQuery9, sqlConnection);

                                    int z = updateCommand10.ExecuteNonQuery();

                                    if (z > 0)
                                    {
                                        Console.WriteLine("Payment Status Updated Successfully");

                                    }
                                    else
                                    {
                                        Console.WriteLine("Data updation Failed");
                                    }

                                    break;

                                default:
                                    Console.WriteLine("Invalid Input !!! Please Choice Valid Input..... ");
                                    break;

                                   

                            }

                           
                            Console.WriteLine("*************************************************************");
                            break;

                        //Delete ---->D
                        case 4:
                            int d_id;
                            Console.WriteLine("Enter the id of the record that is to be Deleted");
                            d_id = int.Parse(Console.ReadLine());
                            String deleteQuery = "DELETE FROM Product_T2 WHERE Customer_Id =" + d_id;
                            SqlCommand deleteCommand = new SqlCommand(deleteQuery, sqlConnection);
                            deleteCommand.ExecuteNonQuery();
                            Console.WriteLine("Data Deleted Successfully");
                            break;
                        case 5:
                            Environment.Exit(0);
                            break;


                        default:
                            Console.WriteLine("Invalid Input !!! Please Choice Valid Input.....\n");
                            break;


                    }
                    Console.WriteLine("Do You Want To Continue? Press y or Y to Continue...");
                    jitin = Console.ReadLine().ToString();
                    Console.Clear();
                } while (jitin == "y" || jitin=="Y");

                
                sqlConnection.Close();



            
            }
            catch (Exception e)
            {
                
                Console.WriteLine(e.Message);
                
            }
            
            finally
            {
                sqlConnection.Close();
            }
            

                Console.ReadLine();
        }
    }
}
